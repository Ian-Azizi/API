package project.services.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import project.entities.users.User;
import project.helper.exception.DataNotFoundException;
import project.helper.utill.SecurityUtils;
import project.repositores.users.userRepository;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
// حتی داکیومنت کردنشم سخته :)))
public class userService {
    @Autowired
    private userRepository repository;

    private SecurityUtils securityUtils;
    public List<User> auth(String username, String password) {
        try {
            password = securityUtils.encryptSHA1(password);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return repository.findAllByUserNameAndPassWord(username,password);
    }
    public List<User> getAll() {
        return getAll();
    }

    public List<User>getUserWord(String username,String password){
        List<User>list=new ArrayList<>();
        return (List<User>) repository.findAllByUserNameAndPassWord(username,password);
    }
    public User getById(long id) {
        Optional<User> data = repository.findAllById(id);
        if (data.isPresent()) return data.get();
        return null;
    }
    public List<User> getByUsername(String username) {
        return repository.findFirstByUserName(username);
    }
    public User add(User data) throws Exception {
//        if(data.getUserName() == null || data.getUserName().equals(""))
//            throw new Exception("Please enter username");
//        List<User> oldUser = getByUsername(data.getUserName());
//
//        //TODO: ex: check password strength
//        if(data.getPassWord() == null || data.getPassWord().equals(""))
//            throw new Exception("Please enter password");
//        data.setPassWord(securityUtils.encryptSHA1(data.getPassWord()));

        return repository.save(data);
    }
    public User upData(User data)  {
        User oldDate = getById(data.getId());
        if (oldDate==null){
            throw new DataNotFoundException("data with id"+data.getId()+"not found");
        }
        oldDate.setUserName(data.getUserName());
        oldDate.setPassWord(data.getPassWord());
        return repository.save(oldDate);

    }
    public boolean deleteById(long id) throws DataNotFoundException {
        User oldDate = getById(id);
        if (oldDate==null){
            throw new DataNotFoundException("data with id"+id+"not found");
        }
        repository.deleteById(id);
        return true;
    }
}

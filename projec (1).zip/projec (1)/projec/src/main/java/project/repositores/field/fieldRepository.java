package project.repositores.field;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import project.entities.field.Field;

@Repository
public interface fieldRepository extends PagingAndSortingRepository<Field,Long> {

}

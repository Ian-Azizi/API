package project.entities.users;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class User {
@GeneratedValue
    @Id
    //دیتا های که لازم است در دیتا بیس ساخته شود.
    //ایدی منحصر به فرد برای تیبل های یتابیس.
    private long id;
    //یوزر نیم
    private String userName;
    //پس ورد
    private String passWord;
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
}

package project.controller.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import project.entities.users.User;
import project.helper.ui.ServiceResponse;
import project.repositores.users.userRepository;
import project.services.user.userService;
import project.helper.ui.ResponseStatus;

import java.util.List;

@RestController
public class userAPI {
    @Autowired
    private userService service;

    @Autowired
    private userRepository repository;

    @PostMapping("/user/login")
    public ServiceResponse<User> login(@RequestBody User user) {
        List<User> userData = service.auth(user.getUserName(), user.getPassWord());
        if (userData == null)
            return new ServiceResponse<User>(ResponseStatus.FAILED, "Incorrect username or password");

        return new ServiceResponse<User>(ResponseStatus.SUCCESS, user);
    }

    @RequestMapping(value = "/test/user", produces = "application/json")
    public Iterable<User> getByUserNameAndPassWord(String username, String password) {
        return repository.findAll();
    }

    @RequestMapping("/user/post")
    public ServiceResponse<User> addUser(@RequestBody User Date) {
        try {
            User adding = service.add(Date);



            return new ServiceResponse<User>(ResponseStatus.SUCCESS, adding);
        } catch (Exception e) {
            return new ServiceResponse<User>(e);
        }
//        return new ServiceResponse<User>(ResponseStatus.SUCCESS, Date);
    }

    @PutMapping("/user/put")
    public ServiceResponse<User> upDateUser(@RequestBody User data) {

        User updateData = service.upData(data);
        return new ServiceResponse<User>(ResponseStatus.SUCCESS, updateData);

//        return new ServiceResponse<User>(ResponseStatus.SUCCESS,data);
    }

    @DeleteMapping("/{id}")
    public ServiceResponse<Boolean> delete(@PathVariable long id) {
        try {
            boolean result = service.deleteById(id);
            return new ServiceResponse<Boolean>(ResponseStatus.SUCCESS, result);
        } catch (Exception e) {
            return new ServiceResponse<Boolean>(e);
        }
    }
}

package project.helper.exception;

public class JwtTokenException extends Throwable {
    public JwtTokenException(String message) {
        super(message);
    }
}

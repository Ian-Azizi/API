package project.repositores.users;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import project.entities.users.User;

import java.util.List;
import java.util.Optional;

@Repository
//ریپازیتوری هستند :)
public interface userRepository extends CrudRepository<User,Long> {
    //درخواست های که از سمت کلاینت برای ثبت نام و ورود خواهد شد یکی یوزر نیم است و دیگری پسورد
        List<User>findAllByUserNameAndPassWord(String username, String password);
    Optional<User> findAllById(long id);
List<User> findFirstByUserName(String Username);

//    @Transactional
//    @Modifying
//    @Query("delete from User u")
//    int deleteById();
//
//    User save(User oldDate);
}

package project.entities.forms;

import jakarta.persistence.*;
import project.entities.field.Field;

//این api برای فرم دانشجو هست
@Entity
public class forms {
@GeneratedValue
    @Id
//ایدی دیتا بیس
    private long id;
//اسم درس
    private String lessen_name;
    //تعداد واحد
    private short unit_number;
    //نام استاد
    private String master_name;
    //ظرفیت
    private short capacity;
    //لینک کردن رشته ها به این فرم
    @ManyToOne
    @JoinColumn(name = "fieldNames")
    private Field field;
    // دکمه چک کردن این فرم
    private boolean haveCheck;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLessen_name() {
        return lessen_name;
    }

    public void setLessen_name(String lessen_name) {
        this.lessen_name = lessen_name;
    }

    public short getUnit_number() {
        return unit_number;
    }

    public void setUnit_number(short unit_number) {
        this.unit_number = unit_number;
    }

    public String getMaster_name() {
        return master_name;
    }

    public void setMaster_name(String master_name) {
        this.master_name = master_name;
    }

    public short getCapacity() {
        return capacity;
    }

    public void setCapacity(short capacity) {
        this.capacity = capacity;
    }
}

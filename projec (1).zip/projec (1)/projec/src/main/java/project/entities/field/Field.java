package project.entities.field;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Field {
@GeneratedValue
    @Id
    private long id;
    private EnumFields enumFields;
    private boolean enable;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public EnumFields getEnumFields() {
        return enumFields;
    }

    public void setEnumFields(EnumFields enumFields) {
        this.enumFields = enumFields;
    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }
}

package project.repositores.forms;

import jakarta.persistence.Entity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import project.entities.forms.forms;

import java.util.List;

@Repository
public interface formsRepository extends CrudRepository<forms,Long> {
    List<forms>findAllById(long id);


}

package project.services.forms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import project.entities.forms.forms;

import project.helper.exception.DataNotFoundException;
import project.helper.utill.SecurityUtils;
import project.repositores.forms.formsRepository;


import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
// حتی داکیومنت کردنشم سخته :)))
public class formsService {
    @Autowired
    private formsRepository repository;


    public List<forms> getAll() {
        return getAll();
    }

    public List<forms>findAllById(long id){
        List<forms>list=new ArrayList<>();
        return repository.findAllById(id);
    }
    public forms getById(long id){
        Optional<forms> data = repository.findById(id);
        if (data.isPresent())return data.get();
        return null;

    }

    public forms add(forms data)  {

        return repository.save(data);
    }
    public forms upData(forms data)  {
        forms oldDate = getById(data.getId());
        if (oldDate==null){
            throw new DataNotFoundException("data with id"+data.getId()+"not found");
        }
            oldDate.setLessen_name(data.getLessen_name());
        oldDate.setCapacity(data.getCapacity());
        oldDate.setUnit_number(data.getUnit_number());
        oldDate.setMaster_name(data.getMaster_name());

        return repository.save(oldDate);

    }
    public boolean deleteById(long id) throws DataNotFoundException {
        forms oldDate = getById(id);
        if (oldDate==null){
            throw new DataNotFoundException("data with id"+id+"not found");
        }
        repository.deleteById(id);
        return true;
    }
}

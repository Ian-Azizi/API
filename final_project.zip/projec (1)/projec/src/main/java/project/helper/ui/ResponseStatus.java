package project.helper.ui;

public enum ResponseStatus {
    SUCCESS,
    FAILED,
    EXCEPTION

}

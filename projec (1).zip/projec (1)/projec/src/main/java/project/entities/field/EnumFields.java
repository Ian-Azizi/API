package project.entities.field;

public enum EnumFields {
    computer,
    mechanic,
    chemistry
}

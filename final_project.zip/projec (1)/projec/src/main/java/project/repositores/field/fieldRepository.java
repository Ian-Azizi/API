package project.repositores.field;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import project.entities.field.Field;

import java.util.List;

@Repository
public interface fieldRepository extends CrudRepository<Field,Long> {
        List<Field>findAllById(long id);

}

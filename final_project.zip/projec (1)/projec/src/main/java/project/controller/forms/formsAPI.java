package project.controller.forms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import project.entities.forms.forms;

import project.helper.ui.ResponseStatus;
import project.helper.ui.ServiceResponse;
import project.repositores.forms.formsRepository;

import project.services.forms.formsService;

import java.util.List;
@RestController
public class formsAPI {
    @Autowired
    private formsService service;

    @Autowired
    private formsRepository repository;



    @RequestMapping(value = "/test/forms", produces = "application/json")
    public Iterable<forms> getId(String company_name){
        return repository.findAll();
    }

    @RequestMapping("/forms/post")
    public ServiceResponse<forms> add(@RequestBody forms Date) {
        try {
            forms adding = service.add(Date);
                        return new ServiceResponse<forms>(ResponseStatus.SUCCESS, adding);
        } catch (Exception e) {
            return new ServiceResponse<forms>(e);
        }
//        return new ServiceResponse<forms>(ResponseStatus.SUCCESS, Date);
    }

    @PutMapping("/forms/put")
    public ServiceResponse<forms> upData(@RequestBody forms data) {

        forms updateData = service.upData(data);
        return new ServiceResponse<forms>(ResponseStatus.SUCCESS, updateData);

//        return new ServiceResponse<forms>(ResponseStatus.SUCCESS,data);
    }

    @DeleteMapping("/forms/{id}")
    public ServiceResponse<Boolean> deleteById(@PathVariable long id) {
        try {
            boolean result = service.deleteById(id);
            return new ServiceResponse<Boolean>(ResponseStatus.SUCCESS, result);
        } catch (Exception e) {
            return new ServiceResponse<Boolean>(e);
        }
    }
}
